% This file contains the (15,11) Hamming parity check matrix stored in the matrix hammingpc.

hammingpc=[  0  0  0  0  1  1  1  1  1  1  1 1  0  0  0;
  1  1  1  0  0  0  0  1  1  1  1 0  1  0  0;
  0  1  1  1  0  1  1  0  0  1  1 0  0  1  0;
  1  0  1  1  1  0  1  0  1  0  1 0  0  0  1];